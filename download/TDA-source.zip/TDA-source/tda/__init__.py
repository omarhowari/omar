"""TDA - serverless LAN messenger (open source, MIT)."""

APP_NAME = "TDA"
APP_VERSION = "1.5.0"
PROTOCOL_VERSION = 1
